<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script defer src="js/app.js"></script>
    <link rel="stylesheet" href="css/status.css"/>
    <link rel="stylesheet" href="css/table.css"/>
    
      <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&display=swap"
      rel="stylesheet"
    />

    <link rel = "icon" 
    href ="img/plvdocxicon.png" 
    type = "image/x-icon">
    
    <title>PLV Docx</title>
  </head>
  
  <body>

    <?php
      include('includes/navbar.php');
    ?>
  
    <main>


    <!-- TO PAY STATUS -->
        <div class="mytabs">
            <input type="radio" id="tabpay" name="mytabs" checked="checked">
            <label for="tabpay">TO PAY</label>
            <div class="tab">
            <div class="wrapper">
                   
                    <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Start / End Time</th>
                                        <th>Batch Type</th>
                                        <th>Training Mode</th>
                                        <th>Batch Status</th>
                                        <th>#</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                </tbody>


                            </table>

                        </div>
                    </div>
                
            </div>
        
            <input type="radio" id="tabprocess" name="mytabs">
            <label for="tabprocess">TO PROCESS</label>
            <div class="tab">
              
            <div class="wrapper">

                    <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Start / End Time</th>
                                        <th>Batch Type</th>
                                        <th>Training Mode</th>
                                        <th>Batch Status</th>
                                        <th>#</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                </tbody>


                            </table>

                        </div>
                    </div>

            </div>

            <input type="radio" id="tabreceive" name="mytabs">
            <label for="tabreceive">TO RECEIVE</label>
            <div class="tab">
              
            <div class="wrapper">
                    <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Start / End Time</th>
                                        <th>Batch Type</th>
                                        <th>Training Mode</th>
                                        <th>Batch Status</th>
                                        <th>#</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                </tbody>


                            </table>

                        </div>

                    </div>

            </div>

            <input type="radio" id="tabcompleted" name="mytabs">
            <label for="tabcompleted" >COMPLETED</label>
            <div class="tab">
              
                <div class="wrapper">
                    <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Start / End Time</th>
                                        <th>Batch Type</th>
                                        <th>Training Mode</th>
                                        <th>Batch Status</th>
                                        <th>#</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                </tbody>


                            </table>

                        </div>

                </div>

            </div>

            <input type="radio" id="tabcancelled" name="mytabs">
            <label for="tabcancelled">CANCELLED</label>
            <div class="tab">
              
                <div class="wrapper">
                        
                <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Start / End Time</th>
                                        <th>Batch Type</th>
                                        <th>Training Mode</th>
                                        <th>Batch Status</th>
                                        <th>#</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                    <tr>
                                        <td data-label="Start Date">1 jan 2021</td>
                                        <td data-label="Start / End Time">09:00 - 13:00 (IST)</td>
                                        <td data-label="Batch Type">Weekend</td>
                                        <td data-label="Training Mode">Online Training</td>
                                        <td data-label="Batch Status"><span class="text_open">[ Open ]</span></td>
                                        <td data-label="#"><a href="#" class="btn">Enroll Now</a></td>
                                    </tr>
                                </tbody>


                            </table>

                        </div>


                </div>

            </div>

    </div>
        
        
    </div>

       

    </main>
   
  </body>
  </html>