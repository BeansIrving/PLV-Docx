<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script defer src="js/app.js"></script>
    <link rel="stylesheet" href="css/accountsettings.css"/>
   

      <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&display=swap"
      rel="stylesheet"
    />

    <link rel = "icon" 
    href ="img/plvdocxicon.png" 
    type = "image/x-icon">

    <title>PLV Docx</title>
  </head>
  
  <body>

    <?php
      include('includes/navbar.php');
    ?>
  
    <main>
        <div class="mytabs">
            <input type="radio" id="tabpay" name="mytabs" checked="checked">
            <label for="tabpay">Account Settings</label>
            <div class="tab">
                <div class="wrapper"></div>
                <main>
                  <form name="my-form" class="formCustom" action="#" method="get">
                        <h3>My Profile</h3>
                        <p>Manage and protect your account</p>
                      <div class="form-boxCustom">
                          <label class="lblCustom" for="studentID">Student ID</label>
                          <input class="inputCustom" type="text" id="studentID" name="studentID" placeholder="18-0208" disabled>
                      </div>
                      <div class="form-boxCustom">
                        <label class="lblCustom" for="name">Name</label>
                        <input class="inputCustom" type="text" id="name" name="name" placeholder="Vince Irving Lucas" disabled>
                      </div>

                      <div class="form-boxCustom">
                        <label class="lblCustom" for="username">username</label>
                        <input class="inputCustom" type="text" id="username" name="username" placeholder="Username" disabled>
                      </div>

                      <div class="form-boxCustom">
                          <label class="lblCustom" for="newpass">New Password</label>
                          <input class="inputCustom" type="password" id="newpass" name="newpass" placeholder="New Password" required>
                      </div>

                      <div class="form-boxCustom">
                        <label class="lblCustom" for="confirmpass">Confirm Password</label>
                        <input class="inputCustom" type="password" id="confirmpass" name="confirmpass" placeholder="Confirm Password" required>
                    </div>
                     
                      <div class="form-boxCustom">
                          <button id="btnConfirm" class="btnCustom">Confirm</button>
                      </div>
                      
                  </form>
              </main>
                  
                </div>
            </div>
          </div>

       

    </main>
   
  </body>
  </html>